"use strict";

const root = document.getElementById("list_employee");

function FormGroup({ label, value, value_multiple, value_multiple_string, value_image, value_video, value_multiple_object, options, type, is_half = false, is_full = false, is_quarter = false, one_row = false }) {
    return (
        <div className={`custom-form-group ${is_half ? 'custom-half' : ''} ${is_full ? 'custom-full-width' : ''}  ${is_quarter ? 'custom-quarter' : ''} ${one_row ? 'custom-form-group-one-row' : ''} `}>
            <p className="custom-form-label">{label}</p>
            {value && <p className={`custom-form-value ${one_row ? 'custom-one-row' : ''}`}>{value}</p>}

            {value_multiple && (
                <div className="custom-form-multiplevalue-wrapper">
                    {value_multiple.map((d, i) => (
                        <div className="custom-form-multiplevalue" key={`form-group-${i}`}>
                            <span className="custom-form-multiplevalue-label">{d.label}</span>
                            <span className="custom-form-multiplevalue-value">
                                : {d.value}
                            </span>
                        </div>
                    ))}
                </div>
            )}

            {value_multiple_string &&
                typeof value_multiple_string == "string" &&
                <ul>
                    {console.log(value_multiple_string)}
                    {value_multiple_string.split(",").map((d, i) => (
                        <li>{d}</li>
                    ))}
                </ul>
            }

            {value_multiple_object &&
                typeof value_multiple_object == "object" &&
                <div className="custom-multipleobject-wrapper">
                    {value_multiple_object.map((d, i) => (
                        <div className="custom-multipleobject-item custom-form-value">

                            {type == "radio" &&
                                <input type="radio" className="custom-radio-label" checked={d.is_selected ? 'checked' : ''} />
                            }

                            {type == "checkbox" &&
                                <input type="checkbox" className="custom-checkbox-label" checked={d.is_selected ? 'checked' : ''} />
                            }

                            <p className={d.is_selected ? '' : 'custom-text-disable'}>{d.name}</p>
                        </div>
                    ))}
                </div>
            }



            {value_image && value_image.length > 0 && (
                <img src={value_image} className="custom-image" />
            )}


            {value_video && value_video.length > 0 && (
                <video width="100%" className="custom-video" controls>
                    <source src={value_video} type="video/mp4" />
                    Your browser does not support the video tag.
                </video>
            )}

        </div>
    );
}

function FormEmployee({ data }) {
    return (
        <React.Fragment>
            <h2>STATUS KELUARGA</h2>
            <hr />
            <div className="custom-form-wrapper">
                <FormGroup label={"No TKA"} value={data.tka_number || "-"} />
                <FormGroup label={"Tanggal Lahir"} value={data.birth_date} />
                <FormGroup label={"Nama"} value={data.name} />
                <FormGroup label={"Tempat Lahir"} value={data.birth_place} />
                <FormGroup label={"Jenis Kelamin"} value={data.gender_label} />
                <FormGroup label={"Agama"} value={data.religion_label} />
                <FormGroup label={"Tinggi Badan"} value={data.body_height} />
                <FormGroup label={"Status"} value={data.marital_status_label} />
                <FormGroup label={"Berat Badan"} value={data.body_weight} />
            </div>
            <br />

            <h2>STATUS KELUARGA</h2>
            <hr />
            <div className="custom-form-wrapper">
                <FormGroup label={"Nama Ayah"} value={data.father_name} />
                <FormGroup label={"Umur"} value={data.father_age} is_half={false} />
                <FormGroup label={"Jumlah Saudara Laki"} value_multiple={[
                    {
                        label: 'Kakak',
                        value: data.brother
                    },
                    {
                        label: 'Adik',
                        value: data.little_brother
                    }
                ]} />
            </div>

            <div className="custom-form-wrapper">
                <FormGroup label={"Nama Ibu"} value={data.mother_name} />
                <FormGroup label={"Umur"} value={data.mother_age} is_half={false} />
                <FormGroup label={"Jumlah Saudara Perempuan"} value_multiple={[
                    {
                        label: 'Kakak',
                        value: data.sister
                    },
                    {
                        label: 'Adik',
                        value: data.little_sister
                    }
                ]} />
            </div>

            <div className="custom-form-wrapper">
                <FormGroup label={"Nama Pasangan"} value={data.partner_name} />
                <FormGroup label={"Umur"} value={data.partner_age} is_half={false} />
                <FormGroup label={"Jumlah Anak"} value_multiple={[
                    {
                        label: 'Kakak',
                        value: data.son_total
                    },
                    {
                        label: 'Adik',
                        value: data.daughter_total
                    }
                ]} />
            </div>

            <div className="custom-form-wrapper">
                <FormGroup label={"Teman / Saudara Di Taiwan"} value={data.is_relative ? "Ada" : "Tidak Ada"} />
                <FormGroup label={"Daerah"} value={data.relative_location} />
            </div>

            <br />

            <div class="custom-wrapper-group">
                <div class="custom-wrapper-item">

                    <h2>DAERAH YANG DIINGINKAN DI TAIWAN</h2>
                    <table width="100%">
                        <tr>
                            {data.subdistricts.map((d) => (
                                <th>{d.name}</th>
                            ))}
                        </tr>
                        <tr>
                            {data.subdistricts.map((d) => {
                                let checked = { checked: 'checked' }

                                return (
                                    <td>
                                        <div class="custom-radio-group-wrapper">
                                            <div class="custom-radio-group">
                                                <input type="radio" className="custom-radio-label" checked={d.is_selected ? 'checked' : ''} />
                                                <p className={d.is_selected ? 'custom-text-bold' : ''}>Iya</p>
                                            </div>

                                            <div class="custom-radio-group">
                                                <input type="radio" className="custom-radio-label" checked={d.is_selected ? '' : 'checked'} />
                                                <p className={!d.is_selected ? 'custom-text-bold' : ''}>Tidak</p>
                                            </div>
                                        </div>
                                    </td>
                                )
                            })}
                        </tr>
                    </table>
                    <br />
                </div>

                <div class="custom-wrapper-item">
                    <h2>KEMAMPUAN BAHASA DAN PENDIDIKAN</h2>
                    <hr />

                    <div className="custom-form-wrapper">
                        <FormGroup label={"Pendidikan Tertinggi"} value_multiple_object={data.education || "-"} is_full={true} type="radio" />
                    </div>

                    <div className="custom-form-wrapper">
                        <FormGroup label={"Jurusan"} value={data.education_major || "-"} is_full={true} />
                    </div>

                    <div className="custom-form-wrapper">
                        <FormGroup label={"Kemampuan Bahasa"} value_multiple_object={data.languages || []} is_full={true} type="checkbox" className="custom-checkbox-label" />
                    </div>

                </div>
            </div>

            <h2>PENGALAMAN KERJA</h2>
            <hr />
            <div>
                <table className="custom-table" width="100%">
                    <thead>
                        <tr>
                            <th className="custom-form-value">NEGARA</th>
                            <th className="custom-form-value">JENIS PT/PABRIK</th>
                            <th className="custom-form-value">MASA KERJA</th>
                            <th className="custom-form-value">ISI PEKERJAAN</th>
                            <th className="custom-form-value">MESIN YANG PERNAH DIOPERASI</th>
                            <th className="custom-form-value">ALASAN BERHENTI</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.employee_jobs &&
                            data.employee_jobs.map((d) => (
                                <tr>
                                    <td>{d.country}</td>
                                    <td>{d.factory_type}</td>
                                    <td>{d.work_experience_start} - {d.work_experience_end}</td>
                                    <td>{d.work}</td>
                                    <td>{d.work_machine}</td>
                                    <td>{d.stop_reason}</td>
                                </tr>
                            ))}
                    </tbody>
                </table>

            </div>

            <div className="custom-form-wrapper">
                <FormGroup label={"Keahlian"} value={data.is_skill ? "Ada" : "Tidak Ada"} is_half={true} />
                <FormGroup label={"Keahlian Dll"} value={data.other_skills} is_half={true} />
            </div>

            <div className="custom-form-wrapper">
                <FormGroup label={null} value_multiple_object={data.skills || []} is_full={true} type="checkbox" className="custom-checkbox-label" />
            </div>
            {/* 
            <div className="custom-form-wrapper">
            </div> */}

            <br />
            <h2>TES LAINNYA</h2>
            <hr />
            <div className="custom-form-wrapper">
                <FormGroup
                    label={"Mata Minus"}
                    value_multiple_object={[
                        {
                            name: "Ada",
                            is_selected: data.minus_eye_label == "Ya"
                        },
                        {
                            name: "Tidak",
                            is_selected: data.minus_eye_label == "Tidak"
                        },
                    ]} type="radio"
                />
                <FormGroup
                    label={"Merokok"}
                    value_multiple_object={[
                        {
                            name: "Ada",
                            is_selected: data.smoking_label == "Ya"
                        },
                        {
                            name: "Tidak",
                            is_selected: data.smoking_label == "Tidak"
                        },
                    ]} type="radio"
                />

                <FormGroup
                    label={"Buta Warna"}
                    value_multiple_object={[
                        {
                            name: "Ada",
                            is_selected: data.colorblind_label == "Ya"
                        },
                        {
                            name: "Tidak",
                            is_selected: data.colorblind_label == "Tidak"
                        },
                    ]} type="radio"
                />

                <FormGroup
                    label={"Kebiasaan Tangan"}
                    value_multiple_object={[
                        {
                            name: "Kiri",
                            is_selected: data.prefered_hand_label == "Kiri"
                        },
                        {
                            name: "Kanan",
                            is_selected: data.prefered_hand_label == "Kanan"
                        },
                    ]} type="radio"
                />

                <FormGroup
                    label={"Push Up"}
                    value_multiple_object={[
                        {
                            name: "<10",
                            is_selected: data.push_up_label == "<10"
                        },
                        {
                            name: ">10",
                            is_selected: data.push_up_label == ">10"
                        },
                    ]} type="radio"
                />

                <FormGroup
                    label={"Tatoo"}
                    value_multiple_object={[
                        {
                            name: "Ada",
                            is_selected: data.tatoo_label == "Ya"
                        },
                        {
                            name: "Tidak",
                            is_selected: data.tatoo_label == "Tidak"
                        },
                    ]} type="radio"
                />

                <FormGroup
                    label={"Minuman Keras"}
                    value_multiple_object={[
                        {
                            name: "Ada",
                            is_selected: data.alcohol_label == "Ya"
                        },
                        {
                            name: "Tidak",
                            is_selected: data.alcohol_label == "Tidak"
                        },
                    ]} type="radio"
                />

                <FormGroup label={"Angkat Beban"} value={data.lifting_power} />

            </div>

            <div className="custom-form-wrapper">
                <FormGroup label={"Kemampuan Bahasa Mandarin"} value_multiple_object={data.mandarin_language} is_full={true} type="radio" className="custom-checkbox-label" />
            </div>

            <div className="custom-form-wrapper">
                <FormGroup
                    label={"Kemampuan Matematika"}
                    is_half={true}
                    value_multiple_object={[
                        {
                            name: "Tambah Kurang",
                            is_selected: data.mathematic_skill_label == "Tambah Kurang"
                        },
                        {
                            name: "Tambah Kurang Kali Bagi",
                            is_selected: data.mathematic_skill_label == "Tambah Kurang Kali Bagi"
                        },
                    ]} type="radio"
                />


                <FormGroup
                    label={"Apakah Tangan Berkeringat"}
                    is_half={true}
                    value_multiple_object={[
                        {
                            name: "Tambah Kurang",
                            is_selected: data.sweaty_hand_label == "Tambah Kurang"
                        },
                        {
                            name: "Tambah Kurang Kali Bagi",
                            is_selected: data.sweaty_hand_label == "Tambah Kurang Kali Bagi"
                        },
                    ]} type="radio"
                />

                <FormGroup
                    label={"Apakah Bersedia tidak merokok"}
                    is_half={true}
                    value_multiple_object={[
                        {
                            name: "Ya",
                            is_selected: data.quit_smoking_label == "Ya"
                        },
                        {
                            name: "Tidak",
                            is_selected: data.quit_smoking_label == "Tidak"
                        },
                    ]} type="radio"
                />

                <FormGroup
                    label={"Apakah Bersedia ikut lembur"}
                    is_half={true}
                    value_multiple_object={[
                        {
                            name: "Ya",
                            is_selected: data.overtime_work_label == "Ya"
                        },
                        {
                            name: "Tidak",
                            is_selected: data.overtime_work_label == "Tidak"
                        },
                    ]} type="radio"
                />

                <div className="custom-form-wrapper">
                    <FormGroup label={"Dokument"} value_multiple_object={data.documents} is_full={true} type="checkbox" className="custom-checkbox-label" />
                </div>

            </div>

            <div className="custom-form-wrapper">
                <FormGroup label={"Foto"} value_image={data.image_path || "-"} is_half={true} />
                <FormGroup label={"Video"} value_video={data.video_path || "-"} is_half={true} />
            </div>



        </React.Fragment>

    )
}

function FormCartaker({ data }) {
    return (
        <React.Fragment>
            <h2>DATA PRIBADI</h2>
            <hr />
            <div className="custom-form-wrapper">
                <FormGroup
                    label={"No Biodata"}
                    value={data.biodata_number || "-"}
                />
                <FormGroup
                    label={"Nama Majikan/Agensi"}
                    value={data.employer_name || "-"}
                />
                <FormGroup label={"Nama CTKW"} value={data.ctkw_name || "-"} />
                <FormGroup
                    label={"Nama Mandarin"}
                    value={data.mandarin_name || "-"}
                />
                <FormGroup label={"Jenis Kelamin"} value={data.gender || "-"} />
                <FormGroup
                    label={"Tanggal Lahir"}
                    value={data.birth_date || "-"}
                />
                <FormGroup
                    label={"Tempat Lahir"}
                    value={data.birth_place || "-"}
                />
                <FormGroup
                    label={"Tinggi Badan"}
                    value={data.body_height || "-"}
                />
                <FormGroup
                    label={"Berat Badan"}
                    value={data.body_weight || "-"}
                />
                <FormGroup label={"Suku"} value={data.ethnic || "-"} />
                <FormGroup
                    label={"Status"}
                    value={data.marital_status_label || "-"}
                />
                <FormGroup label={"Makanan"} value={data.food || "-"} />
                <FormGroup
                    label={"Ex atau NON"}
                    value={data.desired_region || "-"}
                />
                <FormGroup
                    label={"Daerah Yang di Harapkan di Taiwan"}
                    value={data.is_ex || "-"}
                />
                <FormGroup
                    label={"Teman / Saudara Di Taiwan"}
                    value={data.is_relative ? "有 Ada" : "Tidak Ada"}
                />
                <FormGroup label={"Hubungan"} value={data.relative} />
            </div>

            <br />

            <h2>STATUS KELUARGA</h2>
            <hr />
            <div className="custom-form-wrapper">
                <FormGroup label={"Nama Ayah"} value={data.father_name || "-"} is_half={true} />
                <FormGroup label={"Umur"} value={data.father_age || "-"} is_quarter={false} />
                <FormGroup
                    is_quarter={false}
                    label={"No Hp Ayah"}
                    value={data.father_mobile_number || "-"}
                />
            </div>

            <div className="custom-form-wrapper">
                <FormGroup label={"Nama Ibu"} value={data.mother_name || "-"} is_half={true} />
                <FormGroup label={"Umur"} value={data.mother_age || "-"} is_quarter={false} />
                <FormGroup
                    is_quarter={false}
                    label={"No Hp Ibu"}
                    value={data.mother_mobile_number || "-"}
                />
            </div>

            <div className="custom-form-wrapper">
                <FormGroup
                    is_half={true}
                    label={"Nama Suami"}
                    value={data.partner_name || "-"}
                />
                <FormGroup label={"Umur"} value={data.partner_age || "-"} is_quarter={false} />
                <FormGroup
                    is_quarter={false}
                    label={"No Hp Suami"}
                    value={data.partner_mobile_number || "-"}
                />
            </div>

            <div className="custom-form-wrapper">
                <FormGroup
                    is_half={true}
                    label={"Pekerjaan Ayah"}
                    value={data.father_job || "-"}
                />
                <FormGroup
                    is_quarter={false}
                    label={"Pekerjaan Ibu"}
                    value={data.mother_job || "-"}
                />
                <FormGroup
                    is_quarter={false}
                    label={"Pekerjaan Suami"}
                    value={data.partner_job || "-"}
                />
            </div>

            <div className="custom-form-wrapper">
                <FormGroup
                    is_half={true}
                    label={"Jumlah Saudara Kandung :"}
                    value_multiple={[
                        {
                            label: "Laki",
                            value: data.brother,
                        },
                        {
                            label: "Perempuan",
                            value: data.sister,
                        },
                    ]}
                />
                <FormGroup
                    is_quarter={false}
                    label={"Saya Anak Ke"}
                    value={data.child_order || "-"}
                />
                <FormGroup
                    is_quarter={false}
                    label={"Umur Anak"}
                    value_multiple={[
                        {
                            label: "Laki Laki",
                            value: data.son_age,
                        },
                        {
                            label: "Perempuan",
                            value: data.daughter_age,
                        },
                    ]}
                />
            </div>
            <br />
            <h2>KEMAMPUAN BAHASA DAN PENDIDIKAN</h2>
            <hr />

            <div className="custom-form-wrapper">
                <FormGroup label={"Pendidikan Tertinggi"} value_multiple_object={data.education || "-"} is_full={true} type="radio" />
            </div>

            <div className="custom-form-wrapper">
                <p class="custom-title text-bold">Kemampuan Bahasa</p>
                <FormGroup label={"MANDARIN"} one_row={true} value_multiple_object={data.mandarin_language || "-"} is_full={true} type="radio" />
                <FormGroup label={"THAI"} one_row={true} value_multiple_object={data.thai_language || "-"} is_full={true} type="radio" />
                <FormGroup label={"ENGLISH"} one_row={true} value_multiple_object={data.english_language || "-"} is_full={true} type="radio" />
                <FormGroup label={"OTHER"} one_row={true} value_multiple_object={data.other_language || "-"} is_full={true} type="radio" />
            </div>
            <br />

            <h2>PENGALAMAN KERJA</h2>
            <hr />
            <div>
                <table className="custom-table" width="100%">
                    <thead>
                        <tr>
                            <th>NEGARA</th>
                            <th>MASA KERJA</th>
                            <th>JENIS PEKERJAAN</th>
                            <th>YANG DIRAWAT</th>
                            <th>UMUR</th>
                            <th>KEADAAN PASIEN DAN ISI PEKERJAAN</th>
                            <th>ALASAN BERHENTI</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.employee_jobs &&
                            data.employee_jobs.map((d) => (
                                <tr>
                                    <td>{d.country}</td>
                                    <td>{d.work_experience_start} - {d.work_experience_end}</td>
                                    <td>{d.job_type}</td>
                                    <td>{d.recipent_care}</td>
                                    <td>{d.recipent_care_age}</td>
                                    <td>{d.work}</td>
                                    <td>{d.stop_reason}</td>
                                </tr>
                            ))}
                    </tbody>
                </table>
            </div>
            <br />

            <h2>PENGALAMAN DI INDONESIA ATAU DI LUAR NEGERI</h2>
            <hr />
            <div className="custom-form-wrapper">
                <FormGroup
                    is_half={true}
                    type={"checkbox"}
                    label={"Macam Macam Pekerjaan Rumah"}
                    value_multiple_object={data.homework_work_experience || "-"}
                />
                <FormGroup
                    is_half={true}
                    type={"checkbox"}
                    label={"Macam Macam Keperawatan"}
                    value_multiple_object={data.nursing_work_experience || "-"}
                />
            </div>

            <h2>KESEDIAAN BEKERJA DI LUAR NEGERI</h2>
            <hr />
            <div className="custom-form-wrapper">
                <FormGroup
                    is_half={true}
                    type={"checkbox"}
                    label={"Macam Macam Pekerjaan Rumah"}
                    value_multiple_object={data.homework_desired_work || "-"}
                />
                <FormGroup
                    is_half={true}
                    type={"checkbox"}
                    label={"Macam Macam Keperawatan"}
                    value_multiple_object={data.nursing_desired_work || "-"}
                />
            </div>
            <hr />

            <div className="custom-form-wrapper">
                <FormGroup
                    is_full={true}
                    label={"PEKERJAAN YANG DIUTAMAKAN"}
                    type={"checkbox"}
                    value_multiple_object={data.expected_work || "-"}
                />
                <FormGroup
                    is_full={true}
                    label={"MASAKAN TAIWAN"}
                    type={"checkbox"}
                    value_multiple_object={data.taiwan_cooking || "-"}
                />
            </div>

            <div className="custom-form-wrapper">
                <FormGroup label={"KEMAMPUAN GENDONG"} value={data.lifting_power || "-"} />
                <FormGroup label={"MASA BERLAKU PASPOR"} value={data.passport_validity_period || "-"} />
                <FormGroup label={"MASA BERLAKU SKCK"} value={data.skck_validity_period || "-"} />
                <FormGroup label={"PERKIRAAN TANGGAL TERBANG"} value={data.expected_flight_date || "-"} />
            </div>
            <br />

            <h2>KOMENTAR INTERVIEWER DAN GURU</h2>
            <hr />
            <div className="custom-form-wrapper">
                <FormGroup label={"HASIL INTERVIEW"} value={data.interview_result_label || "-"} />
                <FormGroup label={"KOMENTAR GURU"} value={data.teacher_comments || "-"} />
                <FormGroup label={"NO HP"} value={data.mobile_number || "-"} />
                <FormGroup label={"LINE"} value={data.line || "-"} />
                <FormGroup label={"CATATAN"} value={data.notes || "-"} />
                <FormGroup label={"TANGGAL DAFTAR"} value={data.register_date || "-"} />
            </div>

            <div className="custom-form-wrapper">
                <FormGroup label={"Foto"} value_image={data.image_path || "-"} is_half={true} />
                <FormGroup label={"Video"} value_video={data.video_path || "-"} is_half={true} />
            </div>

        </React.Fragment>
    );
}


function DetailModalVideo({ data }) {
    return (
        <div className="custom-modal-video">
            {data.hasOwnProperty('video_path') ?
                <video width="100%" height="100%" className="custom-video-full" controls>
                    <source src={data.video_path} type="video/mp4" />
                    Your browser does not support the video tag.
                </video>
                :
                <p>Video Not Found</p>
            }
        </div>
    );
}

function DetailBiodata({ data }) {
    return (
        <div className="custom-modal-list">
            {data.biodata_type == 3 ?
                <FormEmployee data={data} /> :
                <FormCartaker data={data} />
            }
        </div>
    );
}

function DetailEmployee({ page, lokasi, root_path, endpoint, token }) {
    const [isLoading, setIsLoading] = React.useState(false);
    const [isLoadingDetail, setIsLoadingDetail] = React.useState(false);
    const [data, setData] = React.useState([]);
    const [dataDetail, setDataDetail] = React.useState([]);

    const [dataSelected, setDataSelected] = React.useState(undefined)

    const icon_wa = `${root_path}/assets/img/icon/wa.png`;
    const icon_wa_transparent = `${root_path}/assets/img/icon/wa_transparent.png`;
    const icon_skype_transparent = `${root_path}/assets/img/icon/skype_transparent.png`;

    const icon_skype = `${root_path}/assets/img/icon/skype.png`;
    const icon_video = `${root_path}/assets/img/icon/video.png`;

    const [isModalDetailShow, setIsModalDetailShow] = React.useState(false);
    const [isModalDetailShowVideo, setIsModalDetailShowVideo] = React.useState(false);
    const [hasPage, setHasPage] = React.useState(page != "" || lokasi != "")

    const url_root = endpoint;
    const url_get_employees = url_root + "employees";

    const headers = {
        headers: {
            Authorization: token,
        }
    }

    const payload = () => {
        return {
            page: page,
            location: lokasi
        }
    };

    const openDetail = (employee_id) => {
        setIsModalDetailShow(true);
        loadEmployeeDetail(employee_id);
    };

    const openDetailVideo = (e, _data) => {
        e.preventDefault()
        setDataSelected(_data)
        setIsModalDetailShowVideo(true);
    };

    function FactoryEmployeeCard({ data }) {
        let name = data.name;

        if (data.biodata_type == 1 || data.biodata_type == 2) {
            name = data.ctkw_name;
        }

        return (
            <React.Fragment>
                <div className="custom-card-header" onClick={(e) => openDetailVideo(e, data)}>

                    {data.image_path &&
                        <img src={data.image_path} />
                    }

                    {data.hasOwnProperty('video_path') &&
                        <a className="icon-video" >
                            <img src={icon_video} />
                        </a>
                    }

                </div>
                <div className="custom-card-body">
                    <p className="title">{name || "-"}</p>
                    <p className="description">{`${data.age} YEARS OLD`}</p>
                </div>
                <div className="custom-card-footer">
                    <a className="custom-card-badge" onClick={() => openDetail(data.id)}>
                        Detail
                    </a>
                    {/* <div className="custom-card-badge">{tka}</div> */}

                    {/* <div className="custom-card-footer-sosmed">
                        <a className="custom-icon custom-card-wa"><img src={icon_wa_transparent} /></a>
                        <a className="custom-icon custom-card-skype"><img src={icon_skype_transparent} /></a>
                    </div> */}
                </div>
            </React.Fragment>
        );
    }

    const loadEmployeeDetail = async (employee_id) => {
        if (!isLoadingDetail) {
            setIsLoadingDetail(true);

            const header = {
                ...headers,
                params: payload(),
            };
            return axios
                .get(url_get_employees + "/" + employee_id, header)
                .then((res) => {
                    setIsLoadingDetail(false);
                    if (res.data.hasOwnProperty("data")) {
                        setDataDetail(res.data.data);
                    }
                });
        }
    };

    React.useEffect(() => {
        async function fetchData() {

            if (!hasPage) return

            if (!isLoading) {
                setIsLoading(true);

                const header = {
                    ...headers,
                    params: payload(),
                };
                return axios.get(url_get_employees, header).then((res) => {
                    setIsLoading(false);
                    if (res.data.hasOwnProperty("data")) {
                        setData(res.data.data);
                    }
                });
            }
        }

        fetchData();
        return () => {
            setIsLoading(false);
        };
    }, [page, lokasi]);

    const HideModal = () => {
        setIsModalDetailShow(false);
        setIsModalDetailShowVideo(false);
    };


    React.useEffect(() => {
        function handleOverlayModal() {
            document.addEventListener("click", function (e) {
                if (e.target.classList.contains("custom-modal")) {
                    HideModal()
                }
            })
        }

        handleOverlayModal();

    }, [page, lokasi]);


    if (isLoading) {
        return <React.Fragment></React.Fragment>;
    }

    return (
        <div className="container">
            {/* <div className="custom-backgroup-overlay" style={{ display: isModalDetailShow ? "block" : "none" }} onClick={HideModal}></div> */}
            <div className="custom-modal" style={{ display: isModalDetailShow || isModalDetailShowVideo ? "block" : "none" }}>
                <div className={`custom-modal-content ${isModalDetailShowVideo ? 'custom-modal-auto' : ''}`}>
                    <button className="custom-button-close" onClick={() => HideModal()}>Close</button>

                    {isModalDetailShowVideo &&
                        <DetailModalVideo data={dataSelected} />
                    }

                    {!isLoadingDetail && isModalDetailShow ? (
                        <DetailBiodata data={dataDetail} />
                    ) :
                        isModalDetailShow && <p>Loading...</p>
                    }

                </div>
            </div>
            <div className="custom-card-container">
                {data.map((d, i) => (
                    <div className="custom-card" key={i}>
                        <FactoryEmployeeCard data={d} />
                    </div>
                ))}

                {data.length == 0 && <p>No Data</p>}
            </div>
        </div>
    );
}

if (root) {
    const rootInstance = ReactDOM.createRoot(root);
    const { page, path, lokasi, endpoint, token } = root.dataset;
    rootInstance.render(<DetailEmployee page={page} root_path={path} lokasi={lokasi} endpoint={endpoint} token={token} />);
} else {
    console.error("element not found")
}
