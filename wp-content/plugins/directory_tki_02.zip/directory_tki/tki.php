<?php

/**
 * Plugin Name:         Directory TKI
 * Plugin URI:          https://ivans.my.id
 * Description:         Directory tki
 * Author:              IvanLux
 * Text Domain:         directory-tki
 * Domain Path:         /languages
 * Version:             2.1.2
 * Requires at least:   5.5
 * Requires PHP:        7.3
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * 
 * Repository URI: https://gitlab.com/vincentedison/direktori-tki
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('tki_backend')) {
    function tki_backend()
    {
        add_menu_page(
            'Directory TKI',
            'Directory TKI Options',
            'manage_options',
            'prefixs',
            'save_page'
        );
    }
}

add_action('admin_menu', 'tki_backend');

if (!function_exists('save_page')) {
    function save_page()
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        if (isset($_GET['settings-updated']) && empty(get_settings_errors('prefix_messages'))) {
            add_settings_error('prefix_messages', 'prefix_message', __('Settings Saved', 'prefixs'), 'updated');
        }

        settings_errors('prefix_messages');
    ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            <form action="options.php" method="post">
                <?php
                settings_fields('prefixs');
                do_settings_sections('prefixs');
                submit_button('Save Settings');
                ?>
            </form>
        </div>
    <?php
    }
}

if (!function_exists('field_validation')) {
    function field_validation()
    {
        register_setting('prefixs', 'directory_tki_options', [
            'type'              => 'array',
            'sanitize_callback' => 'message_validation',
        ]);

        add_settings_section(
            'prefix_section_info',
            __('', 'prefixs'),
            'info_callback',
            'prefixs'
        );

        add_settings_field(
            'field_url_endpoint',
            __('URL API', 'prefixs'),
            'url_endpoint',
            'prefixs',
            'prefix_section_info',
            array(
                'url_endpoint' => 'field_url_endpoint',
                'class'     => 'prefix_row',
            )
        );

        add_settings_field(
            'field_token',
            __('Token', 'prefixs'),
            'token',
            'prefixs',
            'prefix_section_info',
            array(
                'token' => 'field_token',
                'class'     => 'prefix_row',
            )
        );
    }
}

add_action('admin_init', 'field_validation');

if (!function_exists('message_validation')) {
    function message_validation($data)
    {
        $old_options = get_option('directory_tki_options');
        $has_errors = false;

        if ($has_errors) {
            $data = $old_options;
        }

        return $data;
    }
}

if (!function_exists('info_callback')) {
    function info_callback($args)
    {
    ?>
        <p id="<?php echo esc_attr($args['id']); ?>"><?php esc_html_e('Please fill in the form correctly', 'prefixs'); ?></p>
    <?php
    }
}

if (!function_exists('url_endpoint')) {
    function url_endpoint($args)
    {
        $options = get_option('directory_tki_options');
        ?>
        <div>
            <input class="regular-text" placeholder="e.g. https://xyz.com/api" type="text" id="<?php echo esc_attr($args['url_endpoint']); ?>" name="directory_tki_options[<?php echo esc_attr($args['url_endpoint']); ?>]" value="<?php echo esc_attr($options[$args['url_endpoint']] ?? ''); ?>">
        </div>
        <?php
    }
}

if (!function_exists('token')) {
    function token($args)
    {
        $options = get_option('directory_tki_options');
        ?>
        <div>
            <input class="regular-text" placeholder="e.g. lux1234aJ5Da" type="text" id="<?php echo esc_attr($args['token']); ?>" name="directory_tki_options[<?php echo esc_attr($args['token']); ?>]" value="<?php echo esc_attr($options[$args['token']] ?? ''); ?>">
        </div>
        <?php
    }
}

add_action('wp_enqueue_scripts', 'scripts_callback');

if (!function_exists('scripts_callback')) {
    function scripts_callback()
    {
        wp_enqueue_style('custom-css', plugins_url('/assets/css/custom.css', __FILE__), array());
        wp_register_script('employee', plugins_url('/assets/js/react/employee.js', __FILE__), ['jquery'], false, true);
        wp_enqueue_script('employee');
        wp_scripts()->add_data('employee', 'type', 'text/babel');

        add_filter('script_loader_tag', 'custom_script_types', 10, 2);
        function custom_script_types($tag, $handle)
        {
            $type = wp_scripts()->get_data($handle, 'type');

            if ($type) {
                $tag = preg_replace(
                    '/ type="(.*?)" /',
                    ' type="' . esc_attr($type) . '" ',
                    $tag
                );
            }

            return $tag;
        }

        wp_enqueue_style('select2t-custom-css', plugins_url('/assets/select2/css/select2.min.css', __FILE__), array(), '2.1.2');
        wp_enqueue_script('select2t-custom-js', plugins_url('/assets/select2/js/select2.min.js', __FILE__), array('jquery'), '2.1.2');

        wp_enqueue_script('react', plugins_url('/assets/js/react.development.js', __FILE__), array(), null, true);
        wp_enqueue_script('babel', plugins_url('/assets/js/babel.js', __FILE__), array(), null, true);
        wp_enqueue_script('react-dom', plugins_url('/assets/js/react-dom.development.js', __FILE__), array('react'), null, true);
        wp_enqueue_script('axios', plugins_url('/assets/js/axios.min.js', __FILE__), array(), null, true);
    }
}

add_action('ux_builder_setup', 'ux_builder_element'); // ux_builder_init @hook

function ux_builder_element()
{
    add_ux_builder_shortcode('ux_menuss', array(
        'type'      => 'container',
        'name'      => __('Menu CNKS', 'flatsome'),
        'category'  => __('Content', 'flatsome'),
        'allow'     => array('ux_menu_link', 'ux_menu_title'),
        'thumbnail' => plugins_url('/directory_tki/assets/img/logo-ux.png'),
        // 'template'  => flatsome_ux_builder_template('ux_menu.html'),
        'wrap'      => false,
        'nested'    => false,
        'presets'   => array(
            array(
                'name'    => __('Default', 'flatsome'),
                'content' => '
                    [ux_menu divider="solid"]
                    [ux_menu_link text="Menu CNKS"]
                    [/ux_menu]	
                ',
            ),
        ),
        'options'   => array(
            'divider'          => array(
                'type'       => 'radio-buttons',
                'heading'    => __('Divider', 'flatsome'),
                'responsive' => true,
                'default'    => '',
                'options'    => array(
                    ''      => array('title' => __('None', 'flatsome')),
                    'solid' => array('title' => __('Solid', 'flatsome')),
                ),
            ),
            // 'advanced_options' => require __DIR__ . '/commons/advanced.php',
        ),
    ));
}



function menu_item($atts, $content, $tag)
{
    $atts = shortcode_atts(
        array(
            'visibility' => '',
            'class'      => '',
            'divider'    => '',
        ),
        $atts,
        $tag
    );

    $classes = array('ux-menus', 'stack', 'stack-col', 'justify-start');

    if (!empty($atts['class']))      $classes[] = $atts['class'];
    if (!empty($atts['divider']))    $classes[] = 'ux-menu--divider-' . $atts['divider'];
    if (!empty($atts['visibility'])) $classes[] = $atts['visibility'];

    wp_enqueue_script('css-vars-polyfill');
    ob_start();

    ?>
        <div class="<?php echo esc_attr(implode(' ', $classes)); ?>">
            <?php
                $current_page_id = basename(get_permalink());
                $data_page_value = $current_page_id;
                $country = get_query_var('country');
                $options = get_option('directory_tki_options');
                $endpoint = $options['field_url_endpoint'] ?? null;
                $country_encode = urlencode($country);
                $token = $options['field_token'] ?? null;
                ?>
                    <div id="list_employee" data-page="<?php echo esc_attr($data_page_value); ?>" data-lokasi="<?php echo $country_encode ?>" data-endpoint="<?php echo esc_html($endpoint); ?>" data-token="<?php echo esc_html($token); ?>" data-path="<?php echo plugins_url('', __FILE__) ?>"></div>
                <?php
            ?>
        </div>
    <?php


    return ob_get_clean();
}
add_shortcode('ux_menuss', 'menu_item');

function add_query_vars_filter($vars)
{
    $vars[] = "country";
    return $vars;
}
add_filter('query_vars', 'add_query_vars_filter');


?>  